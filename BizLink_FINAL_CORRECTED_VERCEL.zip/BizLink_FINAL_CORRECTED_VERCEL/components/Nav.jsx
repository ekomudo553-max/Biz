import Link from "next/link";

export default function Nav() {
  return (
    <nav className="nav">
      <Link className="brand" href="/">BizLink</Link>
      <div className="navlinks">
        <Link href="/businesses">Businesses</Link>
        <Link href="/categories">Categories</Link>
        <Link href="/pricing">Pricing</Link>
        <Link href="/dashboard">Dashboard</Link>
        <Link className="btn" href="/login">Sign in</Link>
      </div>
    </nav>
  );
}
