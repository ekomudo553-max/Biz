# BizLink Deployment Audit

This package was reviewed for the known Vercel/Supabase deployment failures from the project history.

## Fixed
- `useSearchParams()` prerender failure on `/login` — no longer used there.
- Admin page prerendering — `/admin` is `force-dynamic` and uses a client dashboard wrapper.
- Supabase SSR import error — uses `createBrowserClient` / `createServerClient` from `@supabase/ssr`.
- Eager Supabase client creation — clients are created through functions rather than at module load.
- `profiles.updated_at` runtime mismatch — schema now creates/adds `updated_at`, matching the admin role editor.
- Deployment package root — `package.json` is at the project root after extracting this package's inner folder.

## One-time configuration
1. Create/configure the Supabase project.
2. Run `supabase/schema.sql` once (or reconcile it with an already-created database).
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to Vercel once.
4. Create an account, then promote it to admin using the SQL shown in the schema.

Do not put real secrets into the ZIP or GitHub. Vercel project environment variables persist across deployments.

## Important limitation
A full `next build` could not be executed in this environment because package installation/network access was unavailable. The package was statically audited for the known deployment errors, but this is not a claim of a successful remote Vercel build.
