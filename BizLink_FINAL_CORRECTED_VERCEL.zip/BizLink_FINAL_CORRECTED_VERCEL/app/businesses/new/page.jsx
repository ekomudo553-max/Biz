 "use client";

import {useEffect,useState} from "react";
import {createSupabaseBrowserClient} from "../../../lib/supabase/client";

export default function NewBusiness(){
  const [categories,setCategories]=useState([]);
  const [form,setForm]=useState({name:"",description:"",phone:"",address:"",category_id:"",image_url:""});
  const [message,setMessage]=useState("");

  useEffect(()=>{fetch("/api/categories").then(r=>r.json()).then(d=>setCategories(d.categories||[])).catch(()=>{});},[]);

  async function submit(e){
    e.preventDefault();setMessage("");
    const res=await fetch("/api/businesses",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(form)});
    const data=await res.json();
    setMessage(res.ok?"Business submitted for approval.":data.error||"Unable to create business.");
    if(res.ok)setForm({name:"",description:"",phone:"",address:"",category_id:"",image_url:""});
  }

  return <div className="container"><h1>List your business</h1>
    <form className="form" onSubmit={submit}>
      <input className="input" placeholder="Business name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/>
      <select value={form.category_id} onChange={e=>setForm({...form,category_id:e.target.value})} required><option value="">Choose category</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
      <textarea rows="5" placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
      <input className="input" placeholder="Phone" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
      <input className="input" placeholder="Address" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/>
      <input className="input" placeholder="Public image URL (optional)" value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})}/>
      <button className="btn">Submit business</button>
      {message&&<div className="notice">{message}</div>}
    </form>
  </div>
}
