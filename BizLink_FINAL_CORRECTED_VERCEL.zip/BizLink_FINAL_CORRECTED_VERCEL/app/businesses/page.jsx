import { createSupabaseServerClient } from "../../lib/supabase/server";
import BusinessCard from "../../components/BusinessCard";

export const dynamic = "force-dynamic";

export default async function BusinessesPage() {
  let businesses = [];
  let error = null;

  try {
    const supabase = await createSupabaseServerClient();
    const result = await supabase
      .from("businesses")
      .select("id,name,description,image_url,is_featured,category:categories(name)")
      .eq("status","approved")
      .order("is_featured",{ascending:false})
      .order("created_at",{ascending:false});
    businesses = result.data || [];
    error = result.error?.message || null;
  } catch (e) {
    error = e.message;
  }

  return <div className="container">
    <h1>Businesses</h1>
    {error ? <div className="notice">{error}</div> : null}
    <div className="grid">{businesses.map(b=><BusinessCard key={b.id} business={b}/>)}</div>
    {!businesses.length && !error ? <p className="muted">No approved businesses yet.</p> : null}
  </div>;
}
