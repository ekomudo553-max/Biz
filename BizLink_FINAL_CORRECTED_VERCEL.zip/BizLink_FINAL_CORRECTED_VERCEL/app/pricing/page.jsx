import Link from "next/link";

export default function Pricing(){
  return <div className="container"><h1>Pricing</h1><div className="grid">
    <div className="card"><h2>Free</h2><p>Basic business listing.</p><Link className="btn secondary" href="/businesses/new">Get started</Link></div>
    <div className="card"><h2>Featured</h2><p>Promote your business in featured placements.</p><Link className="btn" href="/pricing/checkout">Choose featured</Link></div>
  </div></div>
}
