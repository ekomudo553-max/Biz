'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '../../lib/supabase-browser'

export default function LoginPage() {
  const router = useRouter()
  const [next, setNext] = useState('/')
  const [supabase, setSupabase] = useState(null)

  useEffect(() => {
    const queryNext = new URLSearchParams(window.location.search).get('next') || '/'
    setNext(queryNext)
    setSupabase(createClient())
  }, [])

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleLogin(e) {
    e.preventDefault()
    setLoading(true)
    setError('')

    if (!supabase) {
      setError('Authentication is still loading. Please try again.')
      setLoading(false)
      return
    }

    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      setError('Unable to verify your account.')
      setLoading(false)
      return
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (next.startsWith('/admin') && profile?.role !== 'admin') {
      await supabase.auth.signOut()
      setError('This account does not have administrator access.')
      setLoading(false)
      return
    }

    router.replace(next)
    router.refresh()
  }

  return (
    <main style={styles.page}>
      <form onSubmit={handleLogin} style={styles.card}>
        <div style={styles.logo}>B</div>
        <h1 style={styles.title}>BizLink Admin</h1>
        <p style={styles.subtitle}>Secure administrator login</p>

        <label>Email</label>
        <input type="email" required autoComplete="email"
          value={email} onChange={e => setEmail(e.target.value)}
          placeholder="admin@example.com" style={styles.input} />

        <label>Password</label>
        <input type="password" required autoComplete="current-password"
          value={password} onChange={e => setPassword(e.target.value)}
          placeholder="••••••••" style={styles.input} />

        {error && <div style={styles.error}>{error}</div>}

        <button disabled={loading} style={styles.button}>
          {loading ? 'Signing in...' : 'Sign in'}
        </button>
      </form>
    </main>
  )
}

const styles = {
  page:{minHeight:'100vh',display:'grid',placeItems:'center',background:'#f5f7fa',padding:20,fontFamily:'Arial,sans-serif'},
  card:{width:'100%',maxWidth:420,background:'#fff',padding:32,borderRadius:18,boxShadow:'0 15px 45px rgba(0,0,0,.08)',display:'flex',flexDirection:'column',gap:10},
  logo:{width:52,height:52,borderRadius:14,display:'grid',placeItems:'center',background:'#111827',color:'#fff',fontSize:26,fontWeight:800},
  title:{margin:0,fontSize:30,color:'#111827'},
  subtitle:{margin:'0 0 15px',color:'#667085'},
  input:{width:'100%',boxSizing:'border-box',padding:13,border:'1px solid #d0d5dd',borderRadius:10,fontSize:16},
  button:{marginTop:10,padding:14,border:0,borderRadius:10,background:'#111827',color:'#fff',fontWeight:700,fontSize:16,cursor:'pointer'},
  error:{padding:12,borderRadius:10,background:'#fee4e2',color:'#b42318',fontSize:14}
}
