# Vercel Deployment Checklist

1. Create/import the project in Vercel.
2. Add:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
3. Redeploy.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. Configure Supabase Auth Site URL and redirect URLs for your Vercel domain.
6. Test:
   - Sign up
   - Sign in
   - Categories
   - Add business
   - Business listing
   - Reviews
   - Admin approval
7. Optional payments:
   - Add PAYSTACK_SECRET_KEY
   - Add NEXT_PUBLIC_APP_URL
   - Configure and verify a production webhook before accepting live payments.

Build safety:
The project does not instantiate Supabase clients at module scope. Missing environment variables therefore do not produce `supabaseUrl is required` during `next build`.
